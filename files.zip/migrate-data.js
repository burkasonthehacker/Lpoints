/**
 * migrate-data.js
 * ───────────────────────────────────────────────────────────────
 * סקריפט Node.js להעברת נתונים מהפרויקטים הישנים לפרויקט החדש
 * עם שמות קולקציות חדשים (namespace) כדי שלא ידרסו זה את זה.
 *
 * הרצה:  node migrate-data.js
 *
 * דרישות מוקדמות:
 *   npm install firebase-admin
 *
 * הכנה:
 *   1. ב-Firebase Console של כל פרויקט ישן:
 *      Project Settings → Service accounts → Generate new private key
 *      שמור כ: old-liri-key.json, old-shanan-key.json
 *   2. עשה אותו דבר לפרויקט החדש → new-project-key.json
 * ───────────────────────────────────────────────────────────────
 */

const admin = require("firebase-admin");

// ── הגדר נתיבים לקבצי המפתחות ──
const OLD_LIRI_KEY    = require("./old-liri-key.json");
const OLD_SHANAN_KEY  = require("./old-shanan-key.json");
const NEW_PROJECT_KEY = require("./new-project-key.json");

// אפליקציות firebase-admin נפרדות
const oldLiriApp   = admin.initializeApp({ credential: admin.credential.cert(OLD_LIRI_KEY)    }, "old-liri");
const oldShananApp = admin.initializeApp({ credential: admin.credential.cert(OLD_SHANAN_KEY)  }, "old-shanan");
const newApp       = admin.initializeApp({ credential: admin.credential.cert(NEW_PROJECT_KEY) }, "new");

const oldLiriDb   = admin.firestore(oldLiriApp);
const oldShananDb = admin.firestore(oldShananApp);
const newDb       = admin.firestore(newApp);

// ── מיפוי: קולקציה ישנה → קולקציה חדשה ──
const MIGRATIONS = [
    { sourceDb: oldLiriDb,   oldCol: "friends", newCol: "liri_friends"   },
    { sourceDb: oldLiriDb,   oldCol: "history", newCol: "liri_history"   },
    { sourceDb: oldLiriDb,   oldCol: "updates", newCol: "liri_updates"   },
    { sourceDb: oldShananDb, oldCol: "friends", newCol: "shanan_friends" },
    { sourceDb: oldShananDb, oldCol: "history", newCol: "shanan_history" },
    { sourceDb: oldShananDb, oldCol: "updates", newCol: "shanan_updates" },
];

async function migrateCollection({ sourceDb, oldCol, newCol }) {
    console.log(`\n📦 מעביר: ${oldCol} → ${newCol}`);
    const snapshot = await sourceDb.collection(oldCol).get();
    if (snapshot.empty) { console.log(`   ריק — דילוג`); return; }

    const batch = newDb.batch();
    let count = 0;
    snapshot.docs.forEach(docSnap => {
        const ref = newDb.collection(newCol).doc(docSnap.id);
        batch.set(ref, docSnap.data());
        count++;
    });
    await batch.commit();
    console.log(`   ✅ הועברו ${count} מסמכים`);
}

async function main() {
    console.log("🚀 מתחיל מיגרציה...");
    for (const migration of MIGRATIONS) {
        await migrateCollection(migration);
    }
    console.log("\n✨ מיגרציה הושלמה!");
    process.exit(0);
}

main().catch(err => { console.error("❌ שגיאה:", err); process.exit(1); });
